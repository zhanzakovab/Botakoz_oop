package com.company;

import java.util.ArrayList;

public abstract class PostalOffice {
    protected ArrayList<MagObserver> Mobservers;
    protected ArrayList<PapObserver> Pobservers;
    public PostalOffice() {
        Mobservers = new ArrayList<>();
        Pobservers = new ArrayList<>();
    }
    public void attachMag(MagObserver mobserver) {
        Mobservers.add(mobserver);
    }
    public void detachMag(MagObserver mobserver) {
        Mobservers.remove(mobserver);
    }
    public void attachPap(PapObserver pobserver) {
        Pobservers.add(pobserver);
    }
    public void detachPap(PapObserver pobserver) {
        Pobservers.remove(pobserver);
    }
    protected abstract void notifyMObserver();
    protected abstract void notifyPObserver();
}
