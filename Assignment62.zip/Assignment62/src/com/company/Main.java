package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int number = scan.nextInt();
        Magazine magazine = new Magazine();
        Paper paper = new Paper();
        MagSub obs1 = new MagSub();
        PapSub obs2 = new PapSub();
        magazine.attachMag(obs1);
        paper.attachPap(obs2);
        //Set magazine number
        magazine.setNumber(number);
        //Set paper number
        paper.setNumber(number);
        System.out.println(obs1.getMagazineNumber());
        System.out.println(obs2.getPaperNumber());
        //Detach magazine number
        magazine.detachMag(obs1);
    }
}
