package com.company;

public class Magazine extends PostalOffice {
    private int number;
    public int getNumber() {
        return number;
    }
    public void setNumber(int number) {
        this.number = number;
        notifyMObserver();
    }
    @Override
    protected void notifyMObserver() {
        Mobservers.forEach((Mobserver) -> {
            Mobserver.updateMagazine(number);
        });
    }

    @Override
    protected void notifyPObserver() {

    }
}