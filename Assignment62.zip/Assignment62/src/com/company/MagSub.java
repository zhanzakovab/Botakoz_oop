package com.company;

public class MagSub implements MagObserver {
    private int Magazinenumber;
    public int getMagazineNumber() {
        return Magazinenumber;
    }
    @Override
    public void updateMagazine(int magazineNumber) {
        this.Magazinenumber = magazineNumber;
    }
}

