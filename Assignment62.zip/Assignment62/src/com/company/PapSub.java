package com.company;

public class PapSub implements PapObserver {
    private int Papernumber;
    public int getPaperNumber() {
        return Papernumber;
    }
    @Override
    public void updatePaper(int Pnumber) {
        this.Papernumber = Pnumber;
    }
}
