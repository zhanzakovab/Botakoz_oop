package com.company;

public class Paper extends PostalOffice {
    private int number;
    public int getNumber() {
        return number;
    }
    public void setNumber(int number) {
        this.number = number;
        notifyPObserver();
    }
    @Override
    protected void notifyPObserver() {
        Pobservers.forEach((Pobserver) -> {
            Pobserver.updatePaper(number);
        });
    }

    @Override
    protected void notifyMObserver() {

    }
}
