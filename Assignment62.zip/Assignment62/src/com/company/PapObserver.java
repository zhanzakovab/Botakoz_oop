package com.company;

public interface PapObserver {
        void updatePaper(int Papernumber);
    }