package com.company;

public interface MagObserver {
    void updateMagazine(int Magazinenumber);
}