package com.company;

import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
    System.out.println("Enter character: Orc/Pegasus/Elf/Human");

    try {
        String a = null;
        Scanner scanner = new Scanner(System.in);
        String okay = scanner.nextLine();
        System.out.println("Your choice is :" + okay);
        Characters choose = new Characters();

        if ("Orc".equalsIgnoreCase(okay)) {
            choose.setCharac(new Orc());
        }
        else if ("Pegasus".equalsIgnoreCase(okay)) {
            choose.setCharac(new Pegasus());
        }
        else if ("Elf".equalsIgnoreCase(okay)) {
            choose.setCharac(new Elf());
        }
        else if ("Human".equalsIgnoreCase(okay)) {
            choose.setCharac(new Human());
        }
        else {
            throw new java.lang.RuntimeException("Error Error");
        }

        System.out.println("Mode of action has : "); choose.power();
    }
       catch(NullPointerException e) {
        System.out.println("Error");
    }

}
}
