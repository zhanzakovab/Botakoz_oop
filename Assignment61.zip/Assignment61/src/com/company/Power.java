package com.company;


public interface Power {
    public void power();
}