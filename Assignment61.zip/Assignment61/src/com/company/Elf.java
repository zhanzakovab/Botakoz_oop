package com.company;

public class Elf implements Power {
    @Override
    public void power() {
        System.out.println("I can use the magic!");
    }
}