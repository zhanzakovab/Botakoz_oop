package com.company;

public class Pegasus implements Power {
    @Override
    public void power() {
        System.out.println("I can fly!");
    }
}