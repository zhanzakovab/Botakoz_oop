package com.company;

public class Characters {
    private Power charac;

    public void setCharac(Power a) {
        this.charac = a;
    }

    public Power getAble() {
        return charac;
    }

    public void power(){
        charac.power();
    }
}

