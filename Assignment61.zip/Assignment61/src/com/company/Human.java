package com.company;

public class Human implements Power {
    @Override
    public void power() {
        System.out.println("I am only human, come on!");
    }
}
