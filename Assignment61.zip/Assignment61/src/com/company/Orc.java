package com.company;

public class Orc implements Power {
        @Override
        public void power() {
            System.out.println("I can do anything u want me to do!");
        }
}

